import pyttsx3 #pip install pyttsx3
import speech_recognition as sr #pip install speechRecognition
import datetime
import wikipedia #pip install wikipedia
import webbrowser
import os
import mails
import smtplib
import random
import requests
import json
from selenium import webdriver
from pynput.keyboard import Key, Controller
keyboard_press=Controller()
lst_what_doing=['I am trying to go on moon, but someone has stolen the conductor of my spaceship.','I am waiting for your next question.','I was sleeping, but now I am ready to help you.']
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[1].id)
engine.setProperty('voice', voices[1].id)
lst1=[]
lst2=[]
lst3=[]
city=""

global file_con_name
global text_to_write
global text_to_write2
def speak(audio):
    engine.say(audio)
    engine.runAndWait()


def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Hello! Good Morning...")

    elif hour>=12 and hour<13:
        speak("Hello! Good noon...")   

    elif hour>=13 and hour<19:
        speak("Hello! Good Afternoon...")
    else:
        speak("Hello! Good Evening...")

    speak("How may I assist you ?")
   

def takeCommand():
    #It takes microphone input from the user and returns string output

    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        r.non_speaking_duration = 1
      
        audio = r.listen(source,timeout=None, phrase_time_limit=None)

    try:
        print("Recognizing...")    
        query = r.recognize_google(audio, language='en-IN')
        print(query)
    except Exception:
        #print(e)  
        speak("I'm unable to understand, Please say that again.")
        start_ass()
        return str(0)
        
    return query
your_password=mails.pass_code['pass_s']
your_email=mails.your_mail['e_mail']

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login(your_email,your_password)
    server.sendmail(your_password, to, content)
    server.close()

def hotword():
    
    try:
        r = sr.Recognizer()
        with sr.Microphone() as source:
            r.pause_threshold = 1
            r.non_speaking_duration = 1
            audio = r.listen(source,timeout=None,phrase_time_limit=None)
            if audio:
                query2 = r.recognize_google(audio,language='en-IN')
                if query2:
                    print(query2)
                else:
                    return str(0)
            else:
                start_ass()
        return query2
    except Exception as e:
        print(e)
        hotword().lower()
def start_ass(z=0):
   
    k=z
    try:
        query2=hotword().lower()
    except Exception as e:
        query2=hotword().lower()
    if "lucy" in query2 or "hey lucy" in query2:
        
        if(k==0):
            wishMe()
            z=5
        
        query = takeCommand().lower()

        # Logic for executing tasks based on query
        if 'wikipedia' in query:
            speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("According to Wikipedia")
            print(results)
            speak(results)
            start_ass()

        elif 'the time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M")    
            speak(f"The time is {strTime}")
            start_ass()
        
        elif 'created you' in query or 'made you' in query:
            speak("I am created by group of people, who studies in Lovely Professional University.")
            start_ass()

        elif 'open youtube' in query:
            speak("Opening Youtube")
            webbrowser.open("youtube.com")
            start_ass()

        elif 'open google' in query:
            speak("Opening Google")
            webbrowser.open("google.com")
            start_ass()
            

        elif 'open stackoverflow' in query:
            webbrowser.open("stackoverflow.com")
            start_ass()

        elif 'video song on youtube' in query or 'video on youtube' in query:
            speak("opening youtube on Microsoft edge browser.")
            speak("Getting the latest video song...")
            speak("Here I have got a latest video on youtube...")
            webbrowser.open("youtu.be/PV4LMYstfnI")
            start_ass()
            
        elif 'music' in query:
            ran=random.randint(0,100)
            music_dir2 = r'E:\music'
            songs = os.listdir(music_dir2)
            speak("Playing music on Groove...")
            os.startfile(os.path.join(music_dir2, songs[ran]))
            start_ass()
            

        elif 'video' in query or 'a video' in query or 'a video from my device' in query:
            ran2=random.randint(0,26)
            music_dir=r"C:\\Users\\RESTART\\Videos"
            songs = os.listdir(music_dir)
            speak("Opening video...")
            os.startfile(os.path.join(music_dir, songs[ran2]))
            start_ass()


        elif 'open chrome' in query:
            cpath=r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
            speak("Opening Chrome Browser")
            os.startfile(cpath)
            start_ass()

        elif 'open code' in query:
            codePath = r"C:\\Users\\RESTART\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
            os.startfile(codePath)
            start_ass()
        elif 'who are you' in query:
            speak("Hi, This is Lucy here. Your personal Assistant. I am here to make your life easier. You can command me to perform various tasks such as calculating sums or opening applications etcetra.")
            start_ass()

        elif 'how are you' in query:
            speak("Today's Cloudy weather making me Feel Very well.")
            start_ass()

        elif 'hello' in query:
            speak("Hello! Good to see you.")
            start_ass()

        elif 'are you doing' in query:
            num=random.randint(0,len(lst_what_doing)-1)
            speak(lst_what_doing[num])
            start_ass()

        elif 'gaana' in query or 'on gaana' in query or 'song on gaana' in query:
            if 'song' in query or 'the' in query:
                query=query.replace("the ","")
                query=query.replace("song ","")
            lst1=query[5:-9]
            lst1=lst1.replace(" ","-")
            speak("Here I have got different "+query[5:-9]+" song. Please select the song of your choice from the browser.")
            web_add="https://gaana.com/search/"+lst1
            webbrowser.open(web_add)
            start_ass()


        elif 'shutdown' in query:
            speak("Are you sure you want to shutdown your PC.")
            query2=takeCommand().lower()
            if 'yes' in query2:
                speak("Shutting down your PC.")
                os.system("shutdown /s /t 1")
            else:
                speak("Ok, PC will remain Open.")
                start_ass()

        elif 'restart' in query:
            speak("Are you sure you want to restart your PC.")
            query2=takeCommand().lower()
            if 'yes' in query2:
                speak("Restarting your PC...")
                os.system("shutdown /r /t 1")
            else:
                speak("Ok, PC will remain Open.")
                start_ass()

        elif 'news' in query:
            speak("Here are some category.")
            speak("Business")
            print("1. Business")
            speak("Entertainment")
            print("2. Entertainment")
            speak("Health")
            print("3. Health")
            speak("Science")
            print("4. Science")
            speak("Sports")
            print("5. Sports")
            speak("Technology")
            print("6. Technology")
            get_cat=takeCommand().lower()
            if 'business' in get_cat:
                catg="business"
            elif 'entertainment' in get_cat:
                catg="entertainment"
            elif 'health' in get_cat:
                catg="health"
            elif 'science' in get_cat:
                catg="science"
            elif 'sports' in get_cat:
                catg="sports"
            elif 'technology' in get_cat:
                catg="technology"
            else:
                catg=""
            if catg=="":
                url="https://newsapi.org/v2/top-headlines?country=in&apiKey=4b7f6f7d4b0d492e9bbb9bb107708a65"
            else:
                url="https://newsapi.org/v2/top-headlines?country=in&category="+catg+"&apiKey=4b7f6f7d4b0d492e9bbb9bb107708a65"
            news_str=requests.get(url).text
            news_dict=json.loads(news_str)
            content=news_dict['articles']
            speak("Here is latest news heading...")
            for at in content:
                print(at['title'].replace("-","from"))
                speak(at['title'].replace("-","from"))
                print(at['description'])
                speak(at['description'])
                break
            start_ass()
        
        elif 'air pollution' in query or 'air quality index' in query:
            wea_dict=[]
            wea_dict2=[]
            longi=""
            lati=""
            if 'in' in query:
                b=query.index('in')
                city=query[(b+3):]
            else:
                speak("In which city you are looking for ?")
                city=takeCommand().lower()
            url="http://api.openweathermap.org/data/2.5/weather?appid=e2208cde23193092494196b309a34db1&q="+city+"&units=metric"
            wea_str=requests.get(url).text
            wea_dict=json.loads(wea_str)
            longi=wea_dict['coord']['lon']
            lati=wea_dict['coord']['lat']
            
            url2="http://api.airpollutionapi.com/1.0/aqi?lat="+str(lati)+"&lon="+str(longi)+"&APPID=d2mp6aouvm4hjfigq3e4eejt1h"
            wea_str2=requests.get(url2).text
            wea_dict2=json.loads(wea_str2)
            speak(wea_dict2['data']['alert'])
            start_ass()

        elif 'weather' in query:
            wea_dict=[]
            wea_dict2=[]
            longi=""
            lati=""
            if 'in' in query:
                b=query.index('in')
                city=query[(b+3):]
            else:
                speak("In which city you are looking for ?")
                city=takeCommand().lower()
            url="http://api.openweathermap.org/data/2.5/weather?appid=e2208cde23193092494196b309a34db1&q="+city+"&units=metric"
            wea_str=requests.get(url).text
            wea_dict=json.loads(wea_str)
            speak("Currently in "+city+"the weather report says : "+wea_dict['weather'][0]['description'])
            start_ass()

        elif 'whatsapp' in query or 'whats app' in query:
            chromedriver ="C:\\Users\\RESTART\\OneDrive\\Desktop\\chromedriver\\chromedriver.exe"
            driver= webdriver.Chrome(chromedriver)
            speak("Opening the whatsapp web on Chrome browser.")
            driver.get('http://web.whatsapp.com')
            speak("Now scan the QR code")
            speak("Please say or enter the contact name to whome you want to send message.")
            try:
                temp_name=takeCommand().lower()
                name=retake2(temp_name)
                speak("Please say the message.")
                temp_msg=takeCommand().lower()
                msg=retake2(temp_msg)
                count=int(1)
                #speak("say")
                #ass=takeCommand()
                # input("press Enter")
                keyboard_press.press('\n')
                keyboard_press.release('\n')
            except Exception as e:
                print(e)
                start_ass()
            speak("Sending the Message to "+name)
            user = driver.find_element_by_xpath('//span[@title = "{}"]'.format(name))
            user.click()
            msg_box = driver.find_element_by_class_name('_1Plpp')
            for i in range(count):
                msg_box.send_keys(msg)
                driver.find_element_by_class_name('_35EW6').click()
            start_ass()

            

        elif 'write' in query or 'make' in query or 'make a note' in query:
            speak("Do you want to make a new note, or want to add into existing one ?")
            query3=takeCommand().lower()
            if 'new' in query3 or 'new one' in query3:
                speak("what will be the note name.")
                query4=takeCommand().lower()
                file_con_name=retake(query4)
                add=r"D:\Python Assistant\Assi_notes\\"
                file_name=add+file_con_name+".txt"
                with open(file_name,"a+") as text:
                    if text:
                        speak("Note Created successfully.")
                        speak("Please say whatever you want to write in this note.")
                        query6=takeCommand().lower()
                        text_to_write=retake2(query6)
                        speak("ok,Now writing into the note...")
                        text.write(text_to_write)
                        text.write("\n")
                        text.close()
                        speak("Note written successfully...")
                        start_ass()
                    else:
                        speak("I faced some error while openning the note.")
                        start_ass()
            elif 'existing' in query3 or 'old' in query3:
                speak("Tell me the note name.")
                query4=takeCommand().lower()
                file_con_name=create(query4)
                file_full=file_con_name+".txt"
                note_dir=r"D:\Python Assistant\Assi_notes"
                notes = os.listdir(note_dir)
                if file_full in notes:
                    speak("One note found with name, ")
                    speak(file_con_name)
                    add=r"D:\Python Assistant\Assi_notes\\"
                    file_name=add+file_con_name+".txt"
                    with open(file_name,"a+") as add:
                        if add:
                            speak("Say What do you want to add into this note.")
                            query6=takeCommand().lower()
                            text_to_write2=create2(query6)
                            speak("Now writing into the note.")
                            add.write(text_to_write2)
                            add.write("\n")
                            add.close()
                            speak("Note added successfully...")
                            start_ass()
                        else:
                            speak("I faced some error white opening the note. Please try again.")
                            start_ass()
                else:
                    speak("I didn't found such note named ")
                    speak(file_con_name)
                    print(notes)
                    print(file_con_name)
                    print(file_full)
                    start_ass()
        elif 'in my note' in query or 'any note' in query:
            speak("Geting the list of your notes.")                            
            note_dir=r"D:\Python Assistant\Assi_notes"
            notes = os.listdir(note_dir)
            if notes!=[]:
                speak("Here I have found some notes. Whose names are ")
                for lst1 in notes:
                    speak(lst1)
                speak("Which note do you want to open ?")
                query8=takeCommand().lower()
                add=r"D:\Python Assistant\Assi_notes\\"
                file_name1=query8+".txt"
                filename=add+file_name1
                speak("Opening the note "+query8)
                try:
                    with open(filename,"r") as file_read:
                        for text in file_read:
                            speak(text)
                except Exception as err:
                    print(err)
                    speak(err)
                    start_ass()
                start_ass()
            else:
                speak("There is no existing note found.")
        
        elif 'email' in query or 'mail' in query:
            try:
                speak("Please say the name to whome you want to send the mail.")
                mail_name=takeCommand().lower()
                speak("What should I say?")
                content = takeCommand()
                to = mails.mail[mail_name]    
                sendEmail(to, content)
                speak("Email has been sent!")
                start_ass()
            except Exception as e:
                print(e)
                speak("Sorry. I am not able to send this email")
                start_ass()

        elif 'stop' in query or 'close' in query or 'cancel' in query:
            speak("GoodBye ! See you later.")
        

        else:
            if "0" not in query:
                speak("Searching on google...")
                #query = query.replace(query, "")
                try:
                    results = wikipedia.summary(query, sentences=2)
                    print(results)
                    speak(results)
                    query=""
                    start_ass()
                except Exception as e:
                    start_ass()


    
    elif "lucy" not in query2:
        start_ass()
    else:
        if "0" in query2:
            start_ass()

def retake(q):
    if q:
        speak(q)
        speak("Is it right, or do you want to change it ?")
        query5=takeCommand().lower()
        if 'right' in query5 or 'correct' in query5:
            speak('Ok,Creating a new note named, ')
            speak(q)
            return(q)
        elif 'change' in query5 or 'rename' in query5:
            speak("Ok, tell me the note name again.")
            query4=takeCommand().lower()
            return(retake(query4))
    else:
        speak("Please say again...")
        query4=takeCommand().lower()
        return(retake(query4))

def retake2(q6):
    if q6:
        speak(q6)
        speak("Is this correct, or do you want to change it ?")
        query7=takeCommand().lower()
        if 'correct' in query7 or 'right' in query7 or 'yes' in query7:
            return(q6)
        elif 'change' in query7 or 'rename' in query7:
            speak("Ok, say that again...")
            query6=takeCommand().lower()
            return(retake2(query6))
    else:
        speak("It was not clear, say that again...")
        query6=takeCommand().lower()
        return(retake2(query6))

def create(q):
    if q:
        speak(q)
        speak("Is it right, or do you want to change it ?")
        query5=takeCommand().lower()
        if 'right' in query5 or 'correct' in query5:
            speak('Ok, Searching for note with name, ')
            speak(q)
            return(q)
        elif 'change' in query5 or 'rename' in query5:
            speak("Ok, tell me the note name again.")
            query4=takeCommand().lower()
            return(retake(query4))
    else:
        speak("Please say again...")
        query4=takeCommand().lower()
        return(retake(query4))

def create2(q6):
    if q6:
        speak(q6)
        speak("Is this correct, or do you want to change it ?")
        query7=takeCommand().lower()
        if 'correct' in query7 or 'right' in query7:
            return(q6)
        elif 'change' in query7 or 'rename' in query7:
            speak("Ok, say that again...")
            query6=takeCommand().lower()
            return(retake2(query6))
    else:
        speak("It was not clear, say that again...")
        query6=takeCommand().lower()
        return(retake2(query6))

if __name__ == "__main__": 
    start_ass()
    
        

mail={
    'vashishth':{'guptavashisht237@gmail.com'},
    'yudhister':{'ysharma89kvn@gmail.com'},
    'bhavya':{'bhavyakukreja12@gmail.com'},
    'aditya':{'adichanne@gmail.com'},
    'aman':{'imamanpatel99@gmail.com'}
}

pass_code={
    'pass_s':''
    }

your_mail={
    'e_mail':''
    }
